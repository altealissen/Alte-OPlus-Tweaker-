package com.alte.oplustweaker

import android.content.Context
import android.content.SharedPreferences
import java.io.File

/** Профили оптимизации под Snapdragon 720G (ядро 4.14) */
enum class Profile(
    val id: String,
    val title: String,
    val desc: String,
    val vars: String
) {
    ECO(
        "eco", "Экономия",
        "Потолок частот ~70%, GPU ограничен. Холоднее и дольше держит батарея.",
        "GOV=schedutil\nMIN_L=0\nMIN_B=0\nMAXP=70\nGPU_MIN=0\nGPU_MAX=60\nSWAP=60\nVFS=100\nRA=128\nSTUNE=0\nANIM=1.0\nIO=1"
    ),
    BALANCED(
        "balanced", "Баланс",
        "Штатные частоты + оптимизация диска, памяти и сети. Для повседневной работы.",
        "GOV=schedutil\nMIN_L=0\nMIN_B=0\nMAXP=100\nGPU_MIN=0\nGPU_MAX=100\nSWAP=60\nVFS=100\nRA=128\nSTUNE=0\nANIM=0.7\nIO=1"
    ),
    PERF(
        "perf", "Скорость (рекомендуется)",
        "Повышенные минимальные частоты CPU/GPU, быстрый отклик интерфейса, анимации ×0.5.",
        "GOV=schedutil\nMIN_L=40\nMIN_B=30\nMAXP=100\nGPU_MIN=35\nGPU_MAX=100\nSWAP=80\nVFS=60\nRA=256\nSTUNE=10\nANIM=0.5\nIO=1"
    ),
    GAME(
        "game", "Игровой",
        "Governor performance, высокие частоты GPU. Максимум FPS, телефон заметно греется.",
        "GOV=performance\nMIN_L=100\nMIN_B=100\nMAXP=100\nGPU_MIN=70\nGPU_MAX=100\nSWAP=80\nVFS=50\nRA=512\nSTUNE=20\nANIM=0.5\nIO=1"
    );

    companion object {
        fun byId(id: String?): Profile? = values().firstOrNull { it.id == id }
    }
}

enum class FontPack(val id: String, val title: String, val desc: String, val dir: String) {
    SERIF("serif", "Claude Serif (Lora)", "Засечный шрифт, как текст ответов в Claude. Есть кириллица.", "serif"),
    SANS("sans", "Claude Sans (Inter)", "Современный гротеск, как интерфейс Claude. Есть кириллица.", "sans");

    companion object {
        fun byId(id: String?): FontPack? = values().firstOrNull { it.id == id }
    }
}

object Tweaks {

    fun prefs(ctx: Context): SharedPreferences =
        ctx.getSharedPreferences("alte", Context.MODE_PRIVATE)

    private fun asset(ctx: Context, name: String): String =
        ctx.assets.open("scripts/$name").bufferedReader().use { it.readText() }

    fun apply(ctx: Context, p: Profile): Root.Result {
        val script = p.vars + "\n" + asset(ctx, "lib.sh") + "\n" + asset(ctx, "apply.sh")
        return Root.run(script, 90)
    }


    private fun q(s: String): String = "'" + s.replace("'", "'\\''") + "'"

    fun brand(ctx: Context, from: String, to: String, devName: String): Root.Result {
        val script = "FROM=${q(from)}\nTO=${q(to)}\nDEVNAME=${q(devName)}\n" +
            asset(ctx, "lib.sh") + "\n" + asset(ctx, "brand.sh")
        return Root.run(script, 60)
    }

    fun unbrand(ctx: Context): Root.Result {
        val script = asset(ctx, "lib.sh") + "\n" + asset(ctx, "unbrand.sh")
        return Root.run(script, 60)
    }

    fun applySavedBrand(ctx: Context) {
        val pr = prefs(ctx)
        val to = pr.getString("brand_to", "") ?: ""
        val dev = pr.getString("dev_name", "") ?: ""
        if (to.isEmpty() && dev.isEmpty()) return
        brand(ctx, pr.getString("brand_from", "ColorOS") ?: "ColorOS", to, dev)
    }

    fun installFont(ctx: Context, pack: FontPack): Root.Result {
        val dir = File(ctx.cacheDir, "font_src")
        dir.deleteRecursively()
        dir.mkdirs()
        for (n in listOf("Regular", "Italic", "Bold", "BoldItalic")) {
            ctx.assets.open("fonts/${pack.dir}/$n").use { i ->
                File(dir, n).outputStream().use { o -> i.copyTo(o) }
            }
        }
        val script = "SRC='${dir.absolutePath}'\n" + asset(ctx, "lib.sh") + "\n" + asset(ctx, "font.sh")
        return Root.run(script, 120)
    }

    fun removeFont(ctx: Context): Root.Result = Root.run(asset(ctx, "fontoff.sh"), 30)

    fun reboot(): Root.Result = Root.run("svc power reboot || reboot", 10)

    fun reset(ctx: Context): Root.Result {
        val script = asset(ctx, "lib.sh") + "\n" + asset(ctx, "restore.sh")
        return Root.run(script, 90)
    }

    fun tool(ctx: Context, id: String, timeoutSec: Long): Root.Result {
        val script = "TOOL=$id\n" + asset(ctx, "tool.sh")
        return Root.run(script, timeoutSec)
    }

    fun summary(r: Root.Result): String {
        val last = r.out.lineSequence().lastOrNull { it.isNotBlank() }
        return when {
            !r.ok -> "ошибка: " + (r.err.ifBlank { "нет root-доступа" })
            last != null -> last
            else -> "готово"
        }
    }

    fun readInfo(ctx: Context): Map<String, String> {
        val m = HashMap<String, String>()
        val r = Root.run(asset(ctx, "info.sh"), 15)
        r.out.lineSequence().forEach { l ->
            val i = l.indexOf('=')
            if (i > 0) m[l.substring(0, i)] = l.substring(i + 1)
        }
        runCatching {
            var total = 0L
            var avail = 0L
            File("/proc/meminfo").forEachLine { l ->
                if (l.startsWith("MemTotal:")) total = l.filter { it.isDigit() }.toLongOrNull() ?: 0L
                if (l.startsWith("MemAvailable:")) avail = l.filter { it.isDigit() }.toLongOrNull() ?: 0L
            }
            if (total > 0) m["ram"] = "${avail / 1024} / ${total / 1024} МБ свободно"
        }
        return m
    }
}
