package com.alte.oplustweaker

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color

val Bg = Color(0xFF0B0B10)
val CardBg = Color(0xFF16161F)
val Accent = Color(0xFF8B6CFF)
val Accent2 = Color(0xFFFF4D7A)
val Accent3 = Color(0xFF3D8BFF)
val OkGreen = Color(0xFF4ADE80)
val TextDim = Color(0xFF9A9AB0)

val GradBrush = Brush.linearGradient(listOf(Accent3, Accent, Accent2))

@Composable
fun AlteTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = darkColorScheme(
            primary = Accent,
            secondary = Accent2,
            background = Bg,
            surface = CardBg,
            onSurface = Color.White,
            onBackground = Color.White
        ),
        content = content
    )
}
