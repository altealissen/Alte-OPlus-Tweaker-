package com.alte.oplustweaker

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import androidx.work.ExistingWorkPolicy
import androidx.work.OneTimeWorkRequestBuilder
import androidx.work.WorkManager
import androidx.work.Worker
import androidx.work.WorkerParameters
import java.util.concurrent.TimeUnit

/** После перезагрузки заново применяет последний профиль (дважды: система сама перезаписывает часть значений). */
class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent?) {
        if (intent?.action != Intent.ACTION_BOOT_COMPLETED) return
        val prefs = Tweaks.prefs(context)
        if (!prefs.getBoolean("boot", true)) return
        val hasBrand = !prefs.getString("brand_to", "").isNullOrEmpty() || !prefs.getString("dev_name", "").isNullOrEmpty()
        if (prefs.getString("profile", null) == null && !hasBrand) return
        val wm = WorkManager.getInstance(context)
        for (delaySec in listOf(20L, 90L)) {
            wm.enqueueUniqueWork(
                "alte_boot_$delaySec",
                ExistingWorkPolicy.REPLACE,
                OneTimeWorkRequestBuilder<ApplyWorker>()
                    .setInitialDelay(delaySec, TimeUnit.SECONDS)
                    .build()
            )
        }
    }
}

class ApplyWorker(ctx: Context, params: WorkerParameters) : Worker(ctx, params) {
    override fun doWork(): Result {
        val prof = Profile.byId(Tweaks.prefs(applicationContext).getString("profile", null))
        if (prof != null) Tweaks.apply(applicationContext, prof)
        Tweaks.applySavedBrand(applicationContext)
        return Result.success()
    }
}
