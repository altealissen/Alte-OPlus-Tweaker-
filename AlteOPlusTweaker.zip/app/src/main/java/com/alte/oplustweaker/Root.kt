package com.alte.oplustweaker

import java.util.concurrent.TimeUnit
import kotlin.concurrent.thread

/** Запуск команд от root через su (Magisk / KernelSU / APatch). Скрипт передаётся через stdin. */
object Root {

    data class Result(val code: Int, val out: String, val err: String) {
        val ok: Boolean get() = code == 0
    }

    fun run(script: String, timeoutSec: Long = 60): Result {
        return try {
            val p = ProcessBuilder("su").start()
            val outB = StringBuilder()
            val errB = StringBuilder()
            val t1 = thread { runCatching { p.inputStream.bufferedReader().forEachLine { outB.appendLine(it) } } }
            val t2 = thread { runCatching { p.errorStream.bufferedReader().forEachLine { errB.appendLine(it) } } }
            runCatching {
                p.outputStream.bufferedWriter().use { w ->
                    w.write(script)
                    w.write("\nexit 0\n")
                }
            }
            val done = p.waitFor(timeoutSec, TimeUnit.SECONDS)
            if (!done) {
                p.destroyForcibly()
                return Result(-1, outB.toString().trim(), "таймаут")
            }
            t1.join(2000)
            t2.join(2000)
            Result(p.exitValue(), outB.toString().trim(), errB.toString().trim())
        } catch (e: Exception) {
            Result(-1, "", e.message ?: "ошибка запуска su")
        }
    }

    fun isAvailable(): Boolean {
        val r = run("id", 20)
        return r.out.contains("uid=0")
    }
}
