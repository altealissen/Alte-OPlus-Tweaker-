package com.alte.oplustweaker

import android.os.Build
import androidx.activity.ComponentActivity
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.RadioButton
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

private data class ToolItem(val id: String, val title: String, val timeout: Long)

private val TOOLS = listOf(
    ToolItem("art", "Оптимизация ART", 900),
    ToolItem("trim", "TRIM диска", 120),
    ToolItem("cache", "Очистить кэши", 120),
    ToolItem("ram", "Сбросить кэш RAM", 60),
    ToolItem("kill", "Закрыть фон", 60)
)

@Composable
fun TweakerApp(activity: ComponentActivity) {
    val ctx = activity.applicationContext
    val prefs = remember { Tweaks.prefs(ctx) }
    val scope = rememberCoroutineScope()

    var root by remember { mutableStateOf<Boolean?>(null) }
    var rootTick by remember { mutableStateOf(0) }
    var info by remember { mutableStateOf<Map<String, String>>(emptyMap()) }
    var active by remember { mutableStateOf(prefs.getString("profile", null)) }
    var selected by remember { mutableStateOf(Profile.byId(prefs.getString("profile", null)) ?: Profile.PERF) }
    var bootApply by remember { mutableStateOf(prefs.getBoolean("boot", true)) }
    var busy by remember { mutableStateOf<String?>(null) }
    var resumed by remember { mutableStateOf(true) }
    val log = remember { mutableStateListOf<String>() }
    var brandFrom by remember { mutableStateOf(prefs.getString("brand_from", "ColorOS") ?: "ColorOS") }
    var brandTo by remember { mutableStateOf(prefs.getString("brand_to", "") ?: "") }
    var fontPack by remember { mutableStateOf(FontPack.byId(prefs.getString("font", null)) ?: FontPack.SERIF) }
    var rebootArmed by remember { mutableStateOf(false) }
    var devName by remember { mutableStateOf(prefs.getString("dev_name", "") ?: "") }

    DisposableEffect(Unit) {
        val lc = activity.lifecycle
        val obs = LifecycleEventObserver { _, e ->
            if (e == Lifecycle.Event.ON_RESUME) resumed = true
            else if (e == Lifecycle.Event.ON_PAUSE) resumed = false
        }
        lc.addObserver(obs)
        onDispose { lc.removeObserver(obs) }
    }

    LaunchedEffect(rootTick) {
        root = null
        root = withContext(Dispatchers.IO) { Root.isAvailable() }
    }

    LaunchedEffect(root, resumed) {
        while (root == true && resumed) {
            info = withContext(Dispatchers.IO) { Tweaks.readInfo(ctx) }
            delay(3000)
        }
    }

    fun addLog(s: String) {
        log.add(0, s)
        while (log.size > 30) log.removeAt(log.lastIndex)
    }

    fun applyProfile(p: Profile) {
        if (busy != null || root != true) return
        scope.launch {
            busy = "Применяю «${p.title}»…"
            val r = withContext(Dispatchers.IO) { Tweaks.apply(ctx, p) }
            if (r.ok) {
                active = p.id
                prefs.edit().putString("profile", p.id).apply()
            }
            addLog("«${p.title}»: " + Tweaks.summary(r))
            busy = null
        }
    }

    fun resetAll() {
        if (busy != null || root != true) return
        scope.launch {
            busy = "Возвращаю заводские значения…"
            val r = withContext(Dispatchers.IO) { Tweaks.reset(ctx) }
            if (r.ok) {
                active = null
                prefs.edit().remove("profile").apply()
            }
            addLog("Сброс: " + Tweaks.summary(r))
            busy = null
        }
    }

    fun runTool(t: ToolItem) {
        if (busy != null || root != true) return
        scope.launch {
            busy = t.title + "…"
            val r = withContext(Dispatchers.IO) { Tweaks.tool(ctx, t.id, t.timeout) }
            addLog(t.title + ": " + Tweaks.summary(r))
            busy = null
        }
    }

    fun applyBrand() {
        if (busy != null || root != true) return
        val f = brandFrom.trim()
        val t = brandTo.trim()
        val d = devName.trim()
        if ((f.isEmpty() || t.isEmpty()) && d.isEmpty()) {
            addLog("Кастомизация: заполните «Заменить на» или «Имя устройства»")
            return
        }
        scope.launch {
            busy = "Применяю кастомизацию…"
            val r = withContext(Dispatchers.IO) { Tweaks.brand(ctx, f, t, d) }
            if (r.ok) {
                prefs.edit().putString("brand_from", f).putString("brand_to", t).putString("dev_name", d).apply()
            }
            addLog("Кастомизация: " + Tweaks.summary(r))
            busy = null
        }
    }

    fun revertBrand() {
        if (busy != null || root != true) return
        scope.launch {
            busy = "Откатываю кастомизацию…"
            val r = withContext(Dispatchers.IO) { Tweaks.unbrand(ctx) }
            if (r.ok) {
                prefs.edit().remove("brand_to").remove("dev_name").apply()
                brandTo = ""
                devName = ""
            }
            addLog("Откат: " + Tweaks.summary(r))
            busy = null
        }
    }

    fun installFont() {
        if (busy != null || root != true) return
        val fp = fontPack
        scope.launch {
            busy = "Устанавливаю шрифт «${fp.title}»…"
            val r = withContext(Dispatchers.IO) { Tweaks.installFont(ctx, fp) }
            if (r.ok) prefs.edit().putString("font", fp.id).apply()
            addLog("Шрифт: " + Tweaks.summary(r))
            busy = null
        }
    }

    fun removeFont() {
        if (busy != null || root != true) return
        scope.launch {
            busy = "Удаляю шрифт…"
            val r = withContext(Dispatchers.IO) { Tweaks.removeFont(ctx) }
            addLog("Шрифт: " + Tweaks.summary(r))
            busy = null
        }
    }

    fun rebootNow() {
        if (busy != null || root != true) return
        if (!rebootArmed) {
            rebootArmed = true
            return
        }
        scope.launch { withContext(Dispatchers.IO) { Tweaks.reboot() } }
    }

    val canAct = root == true && busy == null

    Box(Modifier.fillMaxSize().background(Bg)) {
        LazyColumn(
            modifier = Modifier.fillMaxSize().statusBarsPadding().navigationBarsPadding(),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            item { Header() }

            item {
                Panel {
                    when (root) {
                        null -> Text("Проверяю root-доступ…", color = TextDim)
                        true -> Text("Root-доступ получен ✓", color = OkGreen, fontWeight = FontWeight.Bold)
                        false -> {
                            Text(
                                "Root не найден. Выдайте приложению права su в Magisk / KernelSU / APatch и нажмите «Проверить снова».",
                                color = Accent2
                            )
                            Spacer(Modifier.size(10.dp))
                            OutlinedButton(onClick = { rootTick++ }) { Text("Проверить снова") }
                        }
                    }
                    if (busy != null) {
                        Spacer(Modifier.size(10.dp))
                        Text(busy ?: "", color = Color.White, fontSize = 14.sp)
                        Spacer(Modifier.size(6.dp))
                        LinearProgressIndicator(modifier = Modifier.fillMaxWidth())
                    }
                }
            }

            item { DeviceCard(info) }

            item { SectionTitle("Профили") }
            items(Profile.values().toList()) { p ->
                ProfileCard(p, selected == p, active == p.id) { selected = p }
            }
            item {
                GradientButton(
                    text = "Применить «${selected.title}»",
                    enabled = canAct,
                    onClick = { applyProfile(selected) }
                )
            }

            item { SectionTitle("Инструменты") }
            item {
                Panel {
                    TOOLS.chunked(2).forEach { row ->
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            row.forEach { t ->
                                OutlinedButton(
                                    onClick = { runTool(t) },
                                    enabled = canAct,
                                    modifier = Modifier.weight(1f)
                                ) { Text(t.title, fontSize = 13.sp, maxLines = 1) }
                            }
                            if (row.size == 1) Spacer(Modifier.weight(1f))
                        }
                    }
                    Spacer(Modifier.size(4.dp))
                    OutlinedButton(
                        onClick = { resetAll() },
                        enabled = canAct,
                        modifier = Modifier.fillMaxWidth()
                    ) { Text("Сбросить всё к заводским значениям", color = Accent2) }
                }
            }

            item { SectionTitle("Кастомизация") }
            item {
                Panel {
                    Text(
                        "Заменяет текст во всех системных свойствах (то, что показывает «Об устройстве») и меняет имя устройства. Нужен resetprop (Magisk / KernelSU / APatch). Логотип-картинку ColorOS это не меняет. Свойства сбрасываются при перезагрузке и применяются заново автоматически.",
                        color = TextDim, fontSize = 12.sp
                    )
                    Spacer(Modifier.size(8.dp))
                    OutlinedTextField(
                        value = brandFrom, onValueChange = { brandFrom = it },
                        label = { Text("Заменить текст") }, singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                    Spacer(Modifier.size(8.dp))
                    OutlinedTextField(
                        value = brandTo, onValueChange = { brandTo = it },
                        label = { Text("Заменить на (например, Alte OS)") }, singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                    Spacer(Modifier.size(8.dp))
                    OutlinedTextField(
                        value = devName, onValueChange = { devName = it },
                        label = { Text("Имя устройства") }, singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                    Spacer(Modifier.size(10.dp))
                    GradientButton(text = "Применить кастомизацию", enabled = canAct, onClick = { applyBrand() })
                    Spacer(Modifier.size(6.dp))
                    OutlinedButton(
                        onClick = { revertBrand() },
                        enabled = canAct,
                        modifier = Modifier.fillMaxWidth()
                    ) { Text("Откатить кастомизацию", color = Accent2) }
                }
            }

            item { SectionTitle("Шрифт") }
            item {
                Panel {
                    Text(
                        "Меняет системный шрифт (латиница и кириллица) на похожий на Claude. Фирменные шрифты Anthropic закрыты, поэтому используются близкие свободные. Ставится как Magisk-модуль и работает после перезагрузки.",
                        color = TextDim, fontSize = 12.sp
                    )
                    Spacer(Modifier.size(8.dp))
                    FontPack.values().forEach { fp ->
                        Row(
                            Modifier.fillMaxWidth().clickable { fontPack = fp }.padding(vertical = 4.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            RadioButton(selected = fontPack == fp, onClick = null)
                            Spacer(Modifier.width(10.dp))
                            Column {
                                Text(fp.title, color = Color.White, fontWeight = FontWeight.SemiBold, fontSize = 15.sp)
                                Text(fp.desc, color = TextDim, fontSize = 12.sp)
                            }
                        }
                    }
                    if (info["fontmod"] == "1") {
                        Spacer(Modifier.size(6.dp))
                        Text("Модуль шрифта установлен", color = OkGreen, fontSize = 12.sp)
                    }
                    Spacer(Modifier.size(10.dp))
                    GradientButton(text = "Установить шрифт", enabled = canAct, onClick = { installFont() })
                    Spacer(Modifier.size(6.dp))
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedButton(
                            onClick = { removeFont() },
                            enabled = canAct,
                            modifier = Modifier.weight(1f)
                        ) { Text("Вернуть стандартный", fontSize = 13.sp, maxLines = 1, color = Accent2) }
                        OutlinedButton(
                            onClick = { rebootNow() },
                            enabled = canAct,
                            modifier = Modifier.weight(1f)
                        ) {
                            Text(
                                if (rebootArmed) "Нажмите ещё раз" else "Перезагрузить",
                                fontSize = 13.sp, maxLines = 1
                            )
                        }
                    }
                }
            }

            item { SectionTitle("Настройки") }
            item {
                Panel {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text("Применять после перезагрузки", color = Color.White, fontWeight = FontWeight.Medium)
                            Text(
                                "Нужен автозапуск для приложения в настройках ColorOS (Приложения → Alte OPlus Tweaker → Автозапуск).",
                                color = TextDim, fontSize = 12.sp
                            )
                        }
                        Spacer(Modifier.width(8.dp))
                        Switch(checked = bootApply, onCheckedChange = {
                            bootApply = it
                            prefs.edit().putBoolean("boot", it).apply()
                        })
                    }
                }
            }

            if (log.isNotEmpty()) {
                item { SectionTitle("Журнал") }
                item {
                    Panel {
                        log.forEach { Text("• $it", color = TextDim, fontSize = 12.sp) }
                    }
                }
            }
        }
    }
}

@Composable
private fun Header() {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Box(
            Modifier.size(52.dp).clip(RoundedCornerShape(16.dp)).background(GradBrush),
            contentAlignment = Alignment.Center
        ) {
            Text("O+", color = Color.White, fontSize = 22.sp, fontWeight = FontWeight.Bold)
        }
        Spacer(Modifier.width(14.dp))
        Column {
            Text("Alte OPlus Tweaker", color = Color.White, fontSize = 22.sp, fontWeight = FontWeight.Bold)
            Text("Redmi Note 9 Pro · ColorOS 16 · SD 720G", color = TextDim, fontSize = 13.sp)
        }
    }
}

@Composable
private fun SectionTitle(t: String) {
    Text(t, color = Color.White, fontSize = 17.sp, fontWeight = FontWeight.SemiBold, modifier = Modifier.padding(top = 6.dp))
}

@Composable
private fun Panel(content: @Composable () -> Unit) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(18.dp),
        colors = CardDefaults.cardColors(containerColor = CardBg)
    ) {
        Column(Modifier.padding(16.dp)) { content() }
    }
}

@Composable
private fun GradientButton(text: String, enabled: Boolean, onClick: () -> Unit) {
    val shape = RoundedCornerShape(16.dp)
    val bg = if (enabled) GradBrush else SolidColor(Color(0xFF2A2A36))
    Box(
        Modifier
            .fillMaxWidth()
            .clip(shape)
            .background(bg)
            .clickable(enabled = enabled) { onClick() }
            .padding(vertical = 15.dp),
        contentAlignment = Alignment.Center
    ) {
        Text(text, color = if (enabled) Color.White else TextDim, fontWeight = FontWeight.Bold, fontSize = 15.sp)
    }
}

@Composable
private fun ProfileCard(p: Profile, selected: Boolean, active: Boolean, onClick: () -> Unit) {
    val border = if (selected) BorderStroke(2.dp, Accent) else BorderStroke(1.dp, Color(0xFF2A2A36))
    Card(
        modifier = Modifier.fillMaxWidth().clickable { onClick() },
        shape = RoundedCornerShape(18.dp),
        colors = CardDefaults.cardColors(containerColor = CardBg),
        border = border
    ) {
        Row(Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
            RadioButton(selected = selected, onClick = null)
            Spacer(Modifier.width(12.dp))
            Column {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(p.title, color = Color.White, fontWeight = FontWeight.SemiBold, fontSize = 16.sp)
                    if (active) Text("  • активен", color = OkGreen, fontSize = 12.sp)
                }
                Text(p.desc, color = TextDim, fontSize = 13.sp)
            }
        }
    }
}

private fun mhzK(v: String?): String =
    v?.trim()?.toLongOrNull()?.let { "${it / 1000} МГц" } ?: "—"

private fun mhzHz(v: String?): String =
    v?.trim()?.toLongOrNull()?.let { "${it / 1_000_000} МГц" } ?: "—"

@Composable
private fun InfoRow(label: String, value: String) {
    Row(Modifier.fillMaxWidth().padding(vertical = 3.dp)) {
        Text(label, color = TextDim, fontSize = 13.sp, modifier = Modifier.weight(0.38f))
        Text(value, color = Color.White, fontSize = 13.sp, modifier = Modifier.weight(0.62f))
    }
}

@Composable
private fun DeviceCard(info: Map<String, String>) {
    val kernel = System.getProperty("os.version") ?: "—"
    Panel {
        InfoRow("Модель", Build.MODEL)
        InfoRow("Сборка", Build.DISPLAY)
        InfoRow("Android", "${Build.VERSION.RELEASE} (патч ${Build.VERSION.SECURITY_PATCH})")
        InfoRow("Ядро", kernel)
        info["ram"]?.let { InfoRow("RAM", it) }

        info.keys.filter { it.startsWith("cpu_") }.sorted().forEach { k ->
            val p = (info[k] ?: "").split("|")
            InfoRow(
                "CPU " + k.removePrefix("cpu_"),
                "${mhzK(p.getOrNull(0))} · ${p.getOrNull(1) ?: "—"}"
            )
        }
        info["gpu"]?.let { g ->
            val p = g.split("|")
            val busy = p.getOrNull(4)?.trim().orEmpty()
            InfoRow(
                "GPU Adreno",
                "${mhzHz(p.getOrNull(0))} · ${p.getOrNull(1) ?: "—"}" + if (busy.isNotEmpty()) " · $busy" else ""
            )
        }
        info["io"]?.let { v ->
            val p = v.split("|")
            InfoRow("Диск (${p.getOrNull(0)})", "${p.getOrNull(1) ?: "—"} · RA ${p.getOrNull(2) ?: "—"} КБ")
        }
        info["swap"]?.let { InfoRow("swappiness", it) }
        info["tcp"]?.let { InfoRow("TCP", it) }
        info["zram"]?.toLongOrNull()?.let { InfoRow("zram", "${it / 1048576} МБ") }
        info["bat"]?.let { b ->
            val p = b.split("|")
            val t = p.getOrNull(0)?.trim()?.toIntOrNull()
            val c = p.getOrNull(1)?.trim()
            if (t != null) InfoRow("Батарея", "${t / 10}.${t % 10} °C" + if (!c.isNullOrEmpty()) " · $c%" else "")
        }
        if (!kernel.startsWith("4.14")) {
            Spacer(Modifier.size(8.dp))
            Text(
                "Профили рассчитаны на ядро 4.14 (SD 720G). На другом ядре часть пунктов будет пропущена.",
                color = Accent2, fontSize = 12.sp
            )
        }
    }
}
