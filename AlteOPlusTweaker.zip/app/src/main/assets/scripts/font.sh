# ===== установка системного шрифта как Magisk-модуля (применяется после перезагрузки) =====
# переменная: SRC — папка с файлами Regular, Italic, Bold, BoldItalic
MOD=/data/adb/modules/alte_claude_font

if [ ! -d /data/adb/modules ]; then
  echo "Не найден /data/adb/modules (нужен Magisk / KernelSU / APatch)"
  exit 0
fi
for n in Regular Italic Bold BoldItalic; do
  if [ ! -s "$SRC/$n" ]; then
    echo "Нет файла шрифта $n"
    exit 0
  fi
done

pick_font() {
  nm=$(echo "$1" | tr 'A-Z' 'a-z')
  it=""
  bd=""
  case "$nm" in *italic*|*oblique*) it=1 ;; esac
  case "$nm" in *bold*|*black*|*heavy*|*semibold*|*demibold*) bd=1 ;; esac
  if [ -n "$bd" ] && [ -n "$it" ]; then echo BoldItalic
  elif [ -n "$bd" ]; then echo Bold
  elif [ -n "$it" ]; then echo Italic
  else echo Regular
  fi
}

rm -rf "$MOD"
mkdir -p "$MOD/system"
cat > "$MOD/module.prop" <<EOP
id=alte_claude_font
name=Alte Claude Font
version=1.0
versionCode=1
author=Alte OPlus Tweaker
description=Системный шрифт в стиле Claude
EOP

: > "$BK/fonts_found.txt"
N=0
for pair in "/system/fonts:system/fonts" "/system_ext/fonts:system/system_ext/fonts" "/product/fonts:system/product/fonts" "/vendor/fonts:system/vendor/fonts"; do
  srcdir=${pair%%:*}
  dst="$MOD/${pair#*:}"
  [ -d "$srcdir" ] || continue
  for f in "$srcdir"/*; do
    [ -f "$f" ] || continue
    name=${f##*/}
    echo "$srcdir/$name" >> "$BK/fonts_found.txt"
    case "$name" in
      *.ttf|*.otf) ;;
      *) continue ;;
    esac
    case "$name" in
      *Mono*|*Emoji*|*Symbol*|*Hans*|*Hant*|*Jpan*|*Kore*|*Arab*|*Hebr*|*Thai*|*Deva*|*Beng*|*Taml*|*Armn*|*Geor*|*Ethi*|*CJK*) continue ;;
    esac
    case "$name" in
      Roboto*|OPlusSans*|OplusSans*|OPPOSans*|OppoSans*|SysSans-En*|SysFont*|GoogleSans*|ProductSans*) ;;
      *) continue ;;
    esac
    mkdir -p "$dst"
    cp "$SRC/$(pick_font "$name")" "$dst/$name"
    N=$((N+1))
  done
done

if [ "$N" -eq 0 ]; then
  rm -rf "$MOD"
  echo "Подходящие файлы шрифтов не найдены (список: $BK/fonts_found.txt)"
  exit 0
fi

find "$MOD/system" -type d -exec chmod 755 {} \;
find "$MOD/system" -type f -exec chmod 644 {} \;
chcon -R u:object_r:system_file:s0 "$MOD/system" 2>/dev/null
echo "Шрифт установлен: файлов заменено $N. Перезагрузите телефон"
exit 0
