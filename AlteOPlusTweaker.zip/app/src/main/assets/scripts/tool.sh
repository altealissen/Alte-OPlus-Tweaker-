# ===== утилиты (переменная TOOL задана выше) =====
case "$TOOL" in
  art)
    cmd package compile -m speed-profile -a 2>&1 | tail -n 2
    echo "ART-оптимизация завершена"
    ;;
  trim)
    fstrim -v /data 2>&1
    fstrim -v /cache 2>&1
    fstrim -v /metadata 2>&1
    echo "TRIM выполнен"
    ;;
  cache)
    pm trim-caches 999G 2>&1
    echo "Кэши приложений очищены"
    ;;
  ram)
    sync
    echo 3 > /proc/sys/vm/drop_caches 2>/dev/null
    echo 1 > /proc/sys/vm/compact_memory 2>/dev/null
    echo "Кэш RAM сброшен"
    ;;
  kill)
    am kill-all 2>&1
    echo "Фоновые процессы остановлены"
    ;;
esac
exit 0
