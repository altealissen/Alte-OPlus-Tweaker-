rm -rf /data/adb/modules/alte_claude_font
echo "Шрифт удалён. Перезагрузите телефон"
exit 0
