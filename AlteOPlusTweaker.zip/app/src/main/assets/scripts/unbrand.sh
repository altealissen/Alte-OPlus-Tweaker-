# ===== откат кастомизации =====
find_rp
PL=$BK/props.list
N=0
if [ -n "$RP" ] && [ -s "$PL" ]; then
  while IFS='|' read -r n v; do
    [ -n "$n" ] || continue
    if "$RP" "$n" "$v" >/dev/null 2>&1; then
      N=$((N+1))
    fi
  done < "$PL"
  : > "$PL"
fi
if [ -f "$BK/devname.orig" ]; then
  o=$(cat "$BK/devname.orig")
  if [ -z "$o" ] || [ "$o" = "null" ]; then
    settings delete global device_name 2>/dev/null
  else
    settings put global device_name "$o" 2>/dev/null
  fi
  rm -f "$BK/devname.orig"
fi
echo "Восстановлено свойств: $N"
exit 0
