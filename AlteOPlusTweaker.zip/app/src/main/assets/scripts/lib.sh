# ===== общие функции Alte OPlus Tweaker (выполняются от root) =====
BK=/data/local/tmp/alte_oplus_tweaker
MAN=$BK/orig.list
mkdir -p "$BK"
FP=$(getprop ro.build.fingerprint)
if [ "$(cat "$BK/fp" 2>/dev/null)" != "$FP" ]; then
  rm -f "$MAN"
  echo "$FP" > "$BK/fp"
fi
touch "$MAN"
OKN=0
FAILN=0

# прочитать текущее значение (для списков вида "[mq-deadline] none" берём выбранное)
rd() {
  [ -r "$1" ] || return 1
  v=$(cat "$1" 2>/dev/null)
  case "$v" in
    *"["*"]"*) v=$(echo "$v" | sed 's/.*\[\([^]]*\)\].*/\1/') ;;
  esac
  echo "$v"
}

# сохранить оригинальное значение один раз
bk() {
  [ -e "$1" ] || return 1
  if ! grep -q "^$1|" "$MAN" 2>/dev/null; then
    o=$(rd "$1")
    [ -n "$o" ] && echo "$1|$o" >> "$MAN"
  fi
  return 0
}

# записать значение (с резервной копией оригинала)
w() {
  [ -e "$1" ] || return 0
  bk "$1"
  if echo "$2" > "$1" 2>/dev/null; then
    OKN=$((OKN+1))
  else
    FAILN=$((FAILN+1))
  fi
}

# отсортированный список частот из файла
sorted_list() {
  tr ' ' '\n' < "$1" 2>/dev/null | grep -v '^$' | sort -n | tr '\n' ' '
}

# pick ПРОЦЕНТ f1 f2 f3 ... -> частота на этой позиции списка
pick() {
  pct=$1
  shift
  n=$#
  [ "$n" -gt 0 ] || return 1
  i=$(( (n-1)*pct/100 + 1 ))
  eval "echo \${$i}"
}

# найти resetprop (Magisk / KernelSU / APatch)
find_rp() {
  RP=""
  for c in resetprop /data/adb/magisk/resetprop /data/adb/ksu/bin/resetprop /data/adb/ap/bin/resetprop; do
    if command -v "$c" >/dev/null 2>&1 || [ -x "$c" ]; then
      RP="$c"
      break
    fi
  done
}
