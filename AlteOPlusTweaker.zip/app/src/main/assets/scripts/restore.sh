# ===== возврат всех изменённых значений к оригинальным =====
pass() {
  OKN=0
  FAILN=0
  while IFS='|' read -r p v; do
    [ -n "$p" ] || continue
    if echo "$v" > "$p" 2>/dev/null; then
      OKN=$((OKN+1))
    else
      FAILN=$((FAILN+1))
    fi
  done < "$MAN"
}
pass
pass
settings put global window_animation_scale 1.0 2>/dev/null
settings put global transition_animation_scale 1.0 2>/dev/null
settings put global animator_duration_scale 1.0 2>/dev/null
echo "Восстановлено: $OKN, ошибок: $FAILN"
exit 0
