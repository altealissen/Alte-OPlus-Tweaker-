# ===== кастомизация: замена текста в системных свойствах + имя устройства =====
# переменные: FROM, TO, DEVNAME
find_rp
PL=$BK/props.list
touch "$PL"
N=0

if [ -n "$FROM" ] && [ -n "$TO" ]; then
  if [ -z "$RP" ]; then
    echo "resetprop не найден (нужен Magisk / KernelSU / APatch)"
    exit 0
  fi
  getprop | sed -n 's/^\[\([^]]*\)\]: \[\(.*\)\]$/\1|\2/p' > "$BK/all.txt"
  while IFS='|' read -r n v; do
    case "$v" in
      *"$FROM"*)
        nv="${v//"$FROM"/"$TO"}"
        grep -q "^$n|" "$PL" 2>/dev/null || echo "$n|$v" >> "$PL"
        if "$RP" "$n" "$nv" >/dev/null 2>&1; then
          N=$((N+1))
        fi
        ;;
    esac
  done < "$BK/all.txt"
  rm -f "$BK/all.txt"
fi

if [ -n "$DEVNAME" ]; then
  [ -f "$BK/devname.orig" ] || settings get global device_name > "$BK/devname.orig" 2>/dev/null
  settings put global device_name "$DEVNAME" 2>/dev/null
  echo "Имя устройства: $DEVNAME. Изменено свойств: $N"
else
  echo "Изменено свойств: $N"
fi
exit 0
