# ===== применение профиля (переменные GOV, MIN_L, MIN_B, MAXP, ... заданы выше) =====

# ---- CPU ----
for pol in /sys/devices/system/cpu/cpufreq/policy*; do
  [ -d "$pol" ] || continue
  fl=$(sorted_list "$pol/scaling_available_frequencies")
  [ -n "$fl" ] || continue
  case "$pol" in
    *policy0) MINP=$MIN_L ;;
    *) MINP=$MIN_B ;;
  esac
  lowest=$(pick 0 $fl)
  fmax=$(pick $MAXP $fl)
  fmin=$(pick $MINP $fl)
  bk "$pol/scaling_min_freq"
  bk "$pol/scaling_max_freq"
  if [ -n "$GOV" ] && grep -qw "$GOV" "$pol/scaling_available_governors" 2>/dev/null; then
    w "$pol/scaling_governor" "$GOV"
  fi
  echo "$lowest" > "$pol/scaling_min_freq" 2>/dev/null
  w "$pol/scaling_max_freq" "$fmax"
  w "$pol/scaling_min_freq" "$fmin"
done

# ---- GPU Adreno (kgsl devfreq) ----
G=/sys/class/kgsl/kgsl-3d0/devfreq
if [ -d "$G" ]; then
  gl=$(sorted_list "$G/available_frequencies")
  if [ -n "$gl" ]; then
    glow=$(pick 0 $gl)
    gmax=$(pick $GPU_MAX $gl)
    gmin=$(pick $GPU_MIN $gl)
    bk "$G/min_freq"
    bk "$G/max_freq"
    echo "$glow" > "$G/min_freq" 2>/dev/null
    w "$G/max_freq" "$gmax"
    w "$G/min_freq" "$gmin"
  fi
fi

# ---- Накопитель (UFS/eMMC) ----
if [ "$IO" = 1 ]; then
  for b in /sys/block/sd[a-f] /sys/block/mmcblk0; do
    [ -d "$b/queue" ] || continue
    sch=$(cat "$b/queue/scheduler" 2>/dev/null)
    for s in mq-deadline deadline noop none; do
      if echo "$sch" | grep -qw "$s"; then
        w "$b/queue/scheduler" "$s"
        break
      fi
    done
    w "$b/queue/read_ahead_kb" "$RA"
    w "$b/queue/iostats" 0
    w "$b/queue/add_random" 0
    w "$b/queue/rq_affinity" 2
  done
fi

# ---- Память ----
w /proc/sys/vm/swappiness "$SWAP"
w /proc/sys/vm/vfs_cache_pressure "$VFS"
w /proc/sys/vm/page-cluster 0
w /proc/sys/vm/dirty_ratio 20
w /proc/sys/vm/dirty_background_ratio 5

# ---- Сеть ----
if grep -qw bbr /proc/sys/net/ipv4/tcp_available_congestion_control 2>/dev/null; then
  w /proc/sys/net/ipv4/tcp_congestion_control bbr
fi

# ---- Планировщик задач (schedtune, если есть в ядре) ----
if [ -d /dev/stune/top-app ]; then
  w /dev/stune/top-app/schedtune.boost "$STUNE"
  if [ "$STUNE" -gt 0 ]; then
    w /dev/stune/top-app/schedtune.prefer_idle 1
  fi
fi

# ---- Анимации ----
settings put global window_animation_scale "$ANIM" 2>/dev/null
settings put global transition_animation_scale "$ANIM" 2>/dev/null
settings put global animator_duration_scale "$ANIM" 2>/dev/null

echo "Применено: $OKN, пропущено/отказ: $FAILN"
exit 0
