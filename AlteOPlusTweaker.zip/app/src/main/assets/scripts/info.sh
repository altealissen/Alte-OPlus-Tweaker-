echo "kernel=$(uname -r)"
for p in /sys/devices/system/cpu/cpufreq/policy*; do
  [ -d "$p" ] || continue
  echo "cpu_${p##*/}=$(cat $p/scaling_cur_freq 2>/dev/null)|$(cat $p/scaling_governor 2>/dev/null)|$(cat $p/scaling_min_freq 2>/dev/null)|$(cat $p/scaling_max_freq 2>/dev/null)"
done
G=/sys/class/kgsl/kgsl-3d0
if [ -d "$G" ]; then
  gc=$(cat $G/devfreq/cur_freq 2>/dev/null)
  [ -n "$gc" ] || gc=$(cat $G/gpuclk 2>/dev/null)
  echo "gpu=$gc|$(cat $G/devfreq/governor 2>/dev/null)|$(cat $G/devfreq/min_freq 2>/dev/null)|$(cat $G/devfreq/max_freq 2>/dev/null)|$(cat $G/gpu_busy_percentage 2>/dev/null)"
fi
for b in sda mmcblk0; do
  if [ -r /sys/block/$b/queue/scheduler ]; then
    echo "io=$b|$(cat /sys/block/$b/queue/scheduler)|$(cat /sys/block/$b/queue/read_ahead_kb)"
    break
  fi
done
echo "swap=$(cat /proc/sys/vm/swappiness 2>/dev/null)"
echo "tcp=$(cat /proc/sys/net/ipv4/tcp_congestion_control 2>/dev/null)"
echo "zram=$(cat /sys/block/zram0/disksize 2>/dev/null)"
echo "bat=$(cat /sys/class/power_supply/battery/temp 2>/dev/null)|$(cat /sys/class/power_supply/battery/capacity 2>/dev/null)"
[ -d /data/adb/modules/alte_claude_font ] && echo "fontmod=1"
exit 0
